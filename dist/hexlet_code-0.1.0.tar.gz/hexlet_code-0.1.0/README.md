### Hexlet tests and linter status:
[![Actions Status](https://github.com/aleksPOE/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/aleksPOE/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/9b8ebb1f942dfc1c3331/maintainability)](https://codeclimate.com/github/aleksPOE/python-project-49/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/9b8ebb1f942dfc1c3331/test_coverage)](https://codeclimate.com/github/aleksPOE/python-project-49/test_coverage)
